"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Save, Trash2, RefreshCw } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

// Tipos de dados
interface Tank {
  id: string
  name: string
  capacity: number
  level: number
  alertLow: number
  alertMid: number
  alertHigh: number
  height: number
  enabled: boolean
  lastUpdated: string
}

// Dados de exemplo
const mockTank: Tank = {
  id: "1",
  name: "Caixa Principal",
  capacity: 1000,
  level: 65.2,
  alertLow: 20,
  alertMid: 50,
  alertHigh: 90,
  height: 100,
  enabled: true,
  lastUpdated: "2024-03-06 14:30:22",
}

export default function TankSettingsPage() {
  const params = useParams()
  const router = useRouter()
  const [tank, setTank] = useState<Tank | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    name: "",
    capacity: 0,
    height: 0,
    alertLow: 0,
    alertMid: 0,
    alertHigh: 0,
    enabled: true,
  })

  // Carregar dados do tanque
  useEffect(() => {
    // Em um ambiente real, isso seria uma chamada API
    setTank(mockTank)
    setFormData({
      name: mockTank.name,
      capacity: mockTank.capacity,
      height: mockTank.height,
      alertLow: mockTank.alertLow,
      alertMid: mockTank.alertMid,
      alertHigh: mockTank.alertHigh,
      enabled: mockTank.enabled,
    })
    setIsLoading(false)
  }, [params.id])

  // Atualizar campo do formulário
  const updateField = (field: string, value: any) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  // Salvar configurações
  const saveSettings = () => {
    // Validação
    if (!formData.name) {
      toast({
        title: "Campo obrigatório",
        description: "O nome do tanque é obrigatório.",
        variant: "destructive",
      })
      return
    }

    if (formData.capacity <= 0) {
      toast({
        title: "Valor inválido",
        description: "A capacidade deve ser maior que zero.",
        variant: "destructive",
      })
      return
    }

    if (formData.height <= 0) {
      toast({
        title: "Valor inválido",
        description: "A altura deve ser maior que zero.",
        variant: "destructive",
      })
      return
    }

    // Verificar se os níveis de alerta estão em ordem
    if (formData.alertLow >= formData.alertMid || formData.alertMid >= formData.alertHigh) {
      toast({
        title: "Valores inválidos",
        description: "Os níveis de alerta devem estar em ordem crescente (Baixo < Médio < Alto).",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)

    // Em um ambiente real, isso seria uma chamada API
    setTimeout(() => {
      setTank({
        ...tank!,
        ...formData,
        lastUpdated: new Date().toISOString().replace("T", " ").substring(0, 19),
      })
      setIsSaving(false)

      toast({
        title: "Configurações salvas",
        description: "As configurações do tanque foram salvas com sucesso.",
      })

      router.push(`/tanks/${params.id}`)
    }, 1000)
  }

  // Excluir tanque
  const deleteTank = () => {
    // Em um ambiente real, isso seria uma chamada API
    toast({
      title: "Tanque excluído",
      description: "O tanque foi excluído com sucesso.",
    })

    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="container mx-auto p-4 max-w-6xl flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <RefreshCw className="h-12 w-12 text-blue-500 animate-spin mx-auto mb-4" />
          <p className="text-lg">Carregando configurações do tanque...</p>
        </div>
      </div>
    )
  }

  if (!tank) {
    return (
      <div className="container mx-auto p-4 max-w-6xl">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">Tanque não encontrado</h2>
          <p className="mb-4">O tanque solicitado não foi encontrado ou não está disponível.</p>
          <Button onClick={() => router.push("/")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para o Dashboard
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <div className="flex items-center gap-2 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.push(`/tanks/${tank.id}`)}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-bold">Configurações do Tanque</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Configurações Gerais</CardTitle>
          <CardDescription>Configure os parâmetros básicos do tanque</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Tanque</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => updateField("name", e.target.value)}
                placeholder="Ex: Caixa Principal"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="enabled">Status</Label>
              <div className="flex items-center space-x-2">
                <Switch
                  id="enabled"
                  checked={formData.enabled}
                  onCheckedChange={(checked) => updateField("enabled", checked)}
                />
                <Label htmlFor="enabled">{formData.enabled ? "Ativo" : "Inativo"}</Label>
              </div>
            </div>
          </div>

          <Separator />

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="capacity">Capacidade (litros)</Label>
              <Input
                id="capacity"
                type="number"
                value={formData.capacity}
                onChange={(e) => updateField("capacity", Number(e.target.value))}
                min="1"
                step="10"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="height">Altura (cm)</Label>
              <Input
                id="height"
                type="number"
                value={formData.height}
                onChange={(e) => updateField("height", Number(e.target.value))}
                min="1"
                step="1"
              />
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Níveis de Alerta</h3>

            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-1">
                  <Label>Nível Baixo: {formData.alertLow}%</Label>
                </div>
                <Slider
                  value={[formData.alertLow]}
                  min={5}
                  max={40}
                  step={5}
                  onValueChange={(value) => updateField("alertLow", value[0])}
                />
                <p className="text-sm text-muted-foreground mt-1">Alerta quando o nível estiver abaixo deste valor</p>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <Label>Nível Médio: {formData.alertMid}%</Label>
                </div>
                <Slider
                  value={[formData.alertMid]}
                  min={40}
                  max={70}
                  step={5}
                  onValueChange={(value) => updateField("alertMid", value[0])}
                />
                <p className="text-sm text-muted-foreground mt-1">Transição entre nível baixo e alto</p>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <Label>Nível Alto: {formData.alertHigh}%</Label>
                </div>
                <Slider
                  value={[formData.alertHigh]}
                  min={70}
                  max={95}
                  step={5}
                  onValueChange={(value) => updateField("alertHigh", value[0])}
                />
                <p className="text-sm text-muted-foreground mt-1">Alerta quando o nível estiver acima deste valor</p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogTrigger asChild>
              <Button variant="destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Excluir Tanque
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja excluir este tanque? Esta ação não pode ser desfeita.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={deleteTank} className="bg-red-500 hover:bg-red-600">
                  Excluir
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <Button onClick={saveSettings} disabled={isSaving}>
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}


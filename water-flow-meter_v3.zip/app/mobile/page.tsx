"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  DropletIcon,
  History,
  AlertTriangle,
  Droplets,
  ContainerIcon as Tank,
  RefreshCw,
  Settings,
  Menu,
} from "lucide-react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function MobileDashboard() {
  // Estados para simulação de dados
  const [currentFlow, setCurrentFlow] = useState(2.5)
  const [totalVolume, setTotalVolume] = useState(1250.45)
  const [dailyUsage, setDailyUsage] = useState(125.5)
  const [tankLevel, setTankLevel] = useState(65)
  const [tankCapacity, setTankCapacity] = useState(1000)
  const [tankAlertLow, setTankAlertLow] = useState(20)
  const [tankAlertMid, setTankAlertMid] = useState(50)
  const [tankAlertHigh, setTankAlertHigh] = useState(90)
  const [leakDetected, setLeakDetected] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Atualização simulada de dados
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFlow((prev) => {
        const variation = (Math.random() - 0.5) * 0.5
        return Number((prev + variation).toFixed(2))
      })

      setTankLevel((prev) => {
        const variation = (Math.random() - 0.5) * 2
        const newLevel = prev + variation
        return Math.min(Math.max(newLevel, 0), 100)
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  // Determina o status da caixa d'água
  const getTankStatus = () => {
    if (tankLevel <= tankAlertLow) return { status: "Baixo", color: "destructive" }
    if (tankLevel <= tankAlertMid) return { status: "Médio-Baixo", color: "warning" }
    if (tankLevel <= tankAlertHigh) return { status: "Médio-Alto", color: "default" }
    return { status: "Cheio", color: "success" }
  }

  // Calcula o volume atual na caixa
  const getCurrentTankVolume = () => {
    return ((tankLevel / 100) * tankCapacity).toFixed(0)
  }

  // Atualizar dados
  const refreshData = () => {
    setIsRefreshing(true)

    // Simula uma atualização de dados
    setTimeout(() => {
      setCurrentFlow((prev) => {
        const variation = (Math.random() - 0.5) * 1
        return Number((prev + variation).toFixed(2))
      })

      setTankLevel((prev) => {
        const variation = (Math.random() - 0.5) * 5
        const newLevel = prev + variation
        return Math.min(Math.max(newLevel, 0), 100)
      })

      setDailyUsage((prev) => {
        const increase = Math.random() * 2
        return Number((prev + increase).toFixed(2))
      })

      setIsRefreshing(false)
    }, 1500)
  }

  return (
    <div className="container mx-auto p-4 max-w-md">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">Monitoramento de Água</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Menu</SheetTitle>
              </SheetHeader>
              <div className="py-4">
                <div className="space-y-4">
                  <Button variant="ghost" className="w-full justify-start">
                    <DropletIcon className="h-4 w-4 mr-2" />
                    Dashboard
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    <Tank className="h-4 w-4 mr-2" />
                    Caixas d'Água
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    <History className="h-4 w-4 mr-2" />
                    Histórico
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Alertas
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    <Settings className="h-4 w-4 mr-2" />
                    Configurações
                  </Button>
                </div>
                <Separator className="my-4" />
                <Button variant="outline" className="w-full">
                  Sair
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="overview">Resumo</TabsTrigger>
          <TabsTrigger value="tank">Caixa</TabsTrigger>
          <TabsTrigger value="usage">Consumo</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Vazão Atual */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Vazão Atual</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{currentFlow} L/min</div>
              <p className="text-xs text-muted-foreground">Média: 2.8 L/min</p>
            </CardContent>
          </Card>

          {/* Nível da Caixa */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Nível da Caixa</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Progress value={tankLevel} className="h-3" />
                <div className="flex justify-between items-center">
                  <div className="text-lg font-bold">{tankLevel.toFixed(1)}%</div>
                  <Badge variant={getTankStatus().color as any}>{getTankStatus().status}</Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  {getCurrentTankVolume()} de {tankCapacity} litros
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Consumo */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Consumo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-lg font-bold">{dailyUsage.toFixed(1)} L</div>
                  <p className="text-xs text-muted-foreground">Hoje</p>
                </div>
                <div>
                  <div className="text-lg font-bold">{totalVolume.toFixed(0)} L</div>
                  <p className="text-xs text-muted-foreground">Total</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Alertas */}
          {leakDetected && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-red-700 flex items-center">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Vazamento Detectado
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-red-700">
                  Fluxo contínuo detectado nas últimas 6 horas. Verifique suas instalações.
                </p>
              </CardContent>
            </Card>
          )}

          {tankLevel <= tankAlertLow && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-red-700 flex items-center">
                  <Droplets className="h-4 w-4 mr-2" />
                  Nível Crítico
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-red-700">
                  A caixa está com apenas {tankLevel.toFixed(1)}% da capacidade ({getCurrentTankVolume()} litros).
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="tank" className="space-y-4">
          {/* Visualização da Caixa */}
          <Card>
            <CardHeader>
              <CardTitle>Nível da Caixa d'Água</CardTitle>
              <CardDescription>Monitoramento em tempo real</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center">
                {/* Representação visual da caixa */}
                <div className="w-32 h-48 border-2 border-gray-300 rounded-md relative mb-4">
                  <div
                    className={`absolute bottom-0 left-0 right-0 transition-all duration-1000 rounded-b-sm
                      ${
                        tankLevel <= tankAlertLow
                          ? "bg-red-500"
                          : tankLevel <= tankAlertMid
                            ? "bg-yellow-500"
                            : tankLevel <= tankAlertHigh
                              ? "bg-blue-500"
                              : "bg-green-500"
                      }`}
                    style={{ height: `${tankLevel}%` }}
                  />

                  {/* Marcações de nível */}
                  <div className="absolute top-0 left-0 right-0 h-full">
                    <div className="absolute top-[10%] w-full border-t border-gray-400 border-dashed">
                      <span className="absolute -right-8 -top-2 text-xs">90%</span>
                    </div>
                    <div className="absolute top-[50%] w-full border-t border-gray-400 border-dashed">
                      <span className="absolute -right-8 -top-2 text-xs">50%</span>
                    </div>
                    <div className="absolute top-[80%] w-full border-t border-gray-400 border-dashed">
                      <span className="absolute -right-8 -top-2 text-xs">20%</span>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <div className="text-2xl font-bold">{tankLevel.toFixed(1)}%</div>
                  <div className="text-sm">
                    {getCurrentTankVolume()} / {tankCapacity} L
                  </div>
                  <Badge className="mt-2" variant={getTankStatus().color as any}>
                    {getTankStatus().status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Estatísticas */}
          <Card>
            <CardHeader>
              <CardTitle>Estatísticas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Capacidade Total:</span>
                  <span className="font-medium">{tankCapacity} L</span>
                </div>
                <div className="flex justify-between">
                  <span>Volume Atual:</span>
                  <span className="font-medium">{getCurrentTankVolume()} L</span>
                </div>
                <div className="flex justify-between">
                  <span>Espaço Disponível:</span>
                  <span className="font-medium">{(tankCapacity - Number(getCurrentTankVolume())).toFixed(0)} L</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="usage" className="space-y-4">
          {/* Consumo Diário */}
          <Card>
            <CardHeader>
              <CardTitle>Consumo Diário</CardTitle>
              <CardDescription>Últimos 7 dias</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                <div className="flex items-end justify-between h-full">
                  {[65, 85, 125, 95, 115, 125.5, dailyUsage].map((value, index) => (
                    <div
                      key={index}
                      className="w-8 bg-primary rounded-t"
                      style={{ height: `${(value / 150) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>Seg</span>
                <span>Ter</span>
                <span>Qua</span>
                <span>Qui</span>
                <span>Sex</span>
                <span>Sáb</span>
                <span>Hoje</span>
              </div>
            </CardContent>
          </Card>

          {/* Estatísticas de Consumo */}
          <Card>
            <CardHeader>
              <CardTitle>Estatísticas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Consumo Hoje:</span>
                  <span className="font-medium">{dailyUsage.toFixed(1)} L</span>
                </div>
                <div className="flex justify-between">
                  <span>Média Diária:</span>
                  <span className="font-medium">120 L</span>
                </div>
                <div className="flex justify-between">
                  <span>Consumo Mensal:</span>
                  <span className="font-medium">3750.8 L</span>
                </div>
                <div className="flex justify-between">
                  <span>Meta Mensal:</span>
                  <span className="font-medium">4000 L</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-xs">Progresso da Meta</span>
                  <span className="text-xs">93.8%</span>
                </div>
                <Progress value={93.8} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


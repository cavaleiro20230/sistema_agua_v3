import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { EmailAlertService } from "@/components/email-alert-service"

export const metadata: Metadata = {
  title: "Sistema de Monitoramento de Água",
  description: "Monitoramento de fluxo de água e nível da caixa d'água com alertas",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          {children}
          <EmailAlertService />
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'
const functions = require("firebase-functions")
const admin = require("firebase-admin")
const nodemailer = require("nodemailer")

// Initialize Firebase Admin SDK
admin.initializeApp()

// Configure email transporter
const mailTransport = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_APP_PASSWORD, // Use an app password for better security
  },
})

// Function to send email alerts when new alerts are created in the database
exports.sendEmailAlert = functions.database.ref("/alerts/{alertId}").onCreate(async (snapshot, context) => {
  const alertData = snapshot.val()

  // Skip if already processed or no recipients  => {
  // Skip if already processed or no recipients
  if (alertData.processed || !alertData.recipients || alertData.recipients.length === 0) {
    console.log("Alert already processed or has no recipients")
    return null
  }

  // Mark as processed to prevent duplicate emails
  await admin.database().ref(`/alerts/${context.params.alertId}`).update({
    processed: true,
  })

  // Prepare email content
  const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0066cc;">${alertData.subject}</h2>
        <p>${alertData.message.replace(/\n/g, "<br>")}</p>
        <p style="color: #666; font-size: 0.9em;">Enviado em: ${alertData.timestamp}</p>
        <hr>
        <p style="color: #666; font-size: 0.8em;">
          Esta é uma mensagem automática do seu Sistema de Monitoramento de Água.
          Não responda a este email.
        </p>
      </div>
    `

  // Configure email options
  const mailOptions = {
    from: `"Sistema de Monitoramento de Água" <${process.env.EMAIL_USER}>`,
    to: alertData.recipients.join(", "),
    subject: alertData.subject,
    text: alertData.message,
    html: htmlContent,
  }

  try {
    // Send the email
    await mailTransport.sendMail(mailOptions)
    console.log("Email alert sent successfully to:", alertData.recipients.join(", "))

    // Update the alert with success status
    await admin.database().ref(`/alerts/${context.params.alertId}`).update({
      emailSent: true,
      sentTimestamp: admin.database.ServerValue.TIMESTAMP,
    })

    return null
  } catch (error) {
    console.error("Error sending email alert:", error)

    // Update the alert with error status
    await admin.database().ref(`/alerts/${context.params.alertId}`).update({
      emailSent: false,
      error: error.message,
    })

    return null
  }
})

// Function to generate and send daily reports
exports.sendDailyReport = functions.pubsub
  .schedule("0 7 * * *") // Every day at 7 AM
  .timeZone("America/Sao_Paulo") // Adjust to your timezone
  .onRun(async (context) => {
    try {
      // Get email configuration
      const configSnapshot = await admin.database().ref("/emailConfig").once("value")
      const emailConfig = configSnapshot.val()

      if (!emailConfig || !emailConfig.enabled) {
        console.log("Email alerts are disabled")
        return null
      }

      // Get recipients who want daily reports
      const recipients = []
      if (emailConfig.recipients) {
        Object.values(emailConfig.recipients).forEach((recipient) => {
          if (recipient.enabled) {
            recipients.push(recipient.email)
          }
        })
      }

      if (recipients.length === 0) {
        console.log("No recipients configured for daily reports")
        return null
      }

      // Get water system data
      const systemSnapshot = await admin.database().ref("/waterSystem").once("value")
      const systemData = systemSnapshot.val()

      if (!systemData) {
        console.log("No system data available")
        return null
      }

      // Format date
      const today = new Date()
      const dateStr = today.toLocaleDateString("pt-BR")

      // Generate tank status HTML
      let tankStatusHtml = ""
      if (systemData.tanks) {
        Object.entries(systemData.tanks).forEach(([key, tank]) => {
          if (tank.enabled) {
            const tankVolume = (tank.level / 100) * tank.capacity
            tankStatusHtml += `
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">Caixa ${Number.parseInt(key) + 1}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${tank.level.toFixed(1)}%</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${tankVolume.toFixed(0)} L</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${tank.capacity} L</td>
              </tr>
            `
          }
        })
      }

      // Create email content
      const htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0066cc;">Relatório Diário de Consumo de Água</h2>
          <p>Data: <strong>${dateStr}</strong></p>
          
          <h3>Resumo do Consumo</h3>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <tr style="background-color: #f2f2f2;">
              <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Métrica</th>
              <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Valor</th>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">Consumo Diário</td>
              <td style="padding: 8px; border: 1px solid #ddd;">${systemData.dailyUsage.toFixed(2)} L</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">Vazão Atual</td>
              <td style="padding: 8px; border: 1px solid #ddd;">${systemData.flowRate.toFixed(2)} L/min</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">Volume Total</td>
              <td style="padding: 8px; border: 1px solid #ddd;">${systemData.totalVolume.toFixed(2)} L</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">Vazamento Detectado</td>
              <td style="padding: 8px; border: 1px solid #ddd;">${systemData.leakDetected ? "Sim" : "Não"}</td>
            </tr>
          </table>
          
          <h3>Status das Caixas d'Água</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr style="background-color: #f2f2f2;">
              <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Caixa</th>
              <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Nível</th>
              <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Volume</th>
              <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Capacidade</th>
            </tr>
            ${tankStatusHtml}
          </table>
          
          <p style="margin-top: 20px;">Última atualização: ${systemData.lastUpdate || new Date().toLocaleString("pt-BR")}</p>
          
          <hr>
          <p style="color: #666; font-size: 0.8em;">
            Esta é uma mensagem automática do seu Sistema de Monitoramento de Água.
            Não responda a este email.
          </p>
        </div>
      `

      // Configure email options
      const mailOptions = {
        from: `"Sistema de Monitoramento de Água" <${process.env.EMAIL_USER}>`,
        to: recipients.join(", "),
        subject: `Relatório Diário de Consumo de Água - ${dateStr}`,
        html: htmlContent,
      }

      // Send the email
      await mailTransport.sendMail(mailOptions)
      console.log("Daily report sent successfully to:", recipients.join(", "))

      // Log the report in the database
      await admin
        .database()
        .ref("/reports")
        .push({
          type: "daily",
          timestamp: admin.database.ServerValue.TIMESTAMP,
          recipients: recipients,
          data: {
            dailyUsage: systemData.dailyUsage,
            flowRate: systemData.flowRate,
            totalVolume: systemData.totalVolume,
            leakDetected: systemData.leakDetected,
          },
        })

      return null
    } catch (error) {
      console.error("Error sending daily report:", error)
      return null
    }
  })

